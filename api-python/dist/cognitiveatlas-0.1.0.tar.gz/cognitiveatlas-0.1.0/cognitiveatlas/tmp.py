  # STOPPED HERE: TODO: Write a function that can take a term of interest and return
  # the identifier from the rdf.
  # learn here --> http://rdflib.readthedocs.org/en/latest/gettingstarted.html
  # here from Chris --> http://nidm.nidash.org/specs/nidm-results_020.html
  
   # Here is an example of a query OMG IT'S SPARQL-ish :O
        query = """
        prefix prov: <http://www.w3.org/ns/prov#>
        prefix nidm: <http://www.incf.org/ns/nidash/nidm#>
        prefix spm: <http://www.incf.org/ns/nidash/spm#>
        prefix fsl: <http://www.incf.org/ns/nidash/fsl#>
        prefix rdfs: <http://www.w3.org/2000/01/rdf-schema#>
        SELECT ?rdfLabel ?contrastName ?statFile ?statType WHERE {
         ?cid a nidm:ContrastMap ;
              nidm:contrastName ?contrastName ;
              prov:atLocation ?cfile .
         ?cea a nidm:ContrastEstimation .
         ?cid prov:wasGeneratedBy ?cea .
         ?sid a nidm:StatisticMap ;
              nidm:statisticType ?statType ;
              rdfs:label ?rdfLabel ;
              prov:atLocation ?statFile .
        }
        """
        

        # Here is an example of how to do the query (we should do this to get ids for our concepts
        c_results = nidm_g.query(query)
        for row in c_results.bindings:
            c_row = {}
            for key, val in sorted(row.items()):
                c_row[str(key)] = val.decode()
            self.contrasts.append(c_row)

        # uniquify contrast values by file
        self.contrasts = {v['statFile']:v for v in self.contrasts}.values()

        return self.contrasts

